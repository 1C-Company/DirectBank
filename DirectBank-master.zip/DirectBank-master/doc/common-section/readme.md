# Приложения

+ [Обеспечение безопасности данных](https://github.com/1C-Company/DirectBank/blob/master/doc/common-section/data-security.md#-Обеспечение-безопасности-данных)
+ [Классификаторы](https://github.com/1C-Company/DirectBank/blob/master/doc/common-section/tables.md)
+ [Описание типов](https://github.com/1C-Company/DirectBank/blob/master/doc/common-section/type-tables.md)

